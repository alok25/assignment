# Changes to ng-breadcrumbs

## v0.4.0
1. Added #31: Add code coverage
2. Fixed #35: Error: [ngRepeat:dupes]

## v0.3.0

1. Added #34: Use flat-github-ribbon
2. Added #28: Add CHANGES.md
3. Added #33: Add JS style guide .jshintrc file
4. Fixed #32: Duplicate parameter values cause invalid result
