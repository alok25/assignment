define(
  [
    'angular'
  ],
  function(angular) {
    'use strict';

    angular
      .module('ng-breadcrumbs-demo.stock-history-controller', [
        'ng-breadcrumbs-demo'
      ])
      .controller('StockHistoryController', function() {});
  }
);