'use strict';

angular.module('auth', [
    'auth.controller']
)